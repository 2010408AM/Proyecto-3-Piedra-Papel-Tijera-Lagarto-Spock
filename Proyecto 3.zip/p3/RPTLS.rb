# RPTLS: Proyecto 3 
# Integrantes: Alejandra Mármol 2010408 -- Rosa Ramirez 2010527

# Jerarquía de jugadas
class Jugada
  attr_reader :nombre
  
  def initialize(nombre)
    @nombre = nombre
  end
  
  def to_s
    @nombre.to_s
  end
  
  def puntos(contrincante)
    if gana_a?(contrincante)
      [1, 0]
    elsif contrincante.gana_a?(self)
      [0, 1]
    else
      [0, 0]
    end
  end
  
  def gana_a?(contrincante)
    false
  end
  
  def ==(otra)
    self.class == otra.class
  end
end

class Piedra < Jugada
  def initialize
    super(:Piedra)
  end
  
  def gana_a?(contrincante)
    contrincante.is_a?(Tijera) || contrincante.is_a?(Lagarto)
  end
end

class Papel < Jugada
  def initialize
    super(:Papel)
  end
  
  def gana_a?(contrincante)
    contrincante.is_a?(Piedra) || contrincante.is_a?(Spock)
  end
end

class Tijera < Jugada
  def initialize
    super(:Tijera)
  end
  
  def gana_a?(contrincante)
    contrincante.is_a?(Papel) || contrincante.is_a?(Lagarto)
  end
end

class Lagarto < Jugada
  def initialize
    super(:Lagarto)
  end
  
  def gana_a?(contrincante)
    contrincante.is_a?(Papel) || contrincante.is_a?(Spock)
  end
end

class Spock < Jugada
  def initialize
    super(:Spock)
  end
  
  def gana_a?(contrincante)
    contrincante.is_a?(Tijera) || contrincante.is_a?(Piedra)
  end
end

# Jerarquía de estrategias
class Estrategia
  @@semillaPadre = 42
  
  def initialize
    @random = Random.new(@@semillaPadre)
  end
  
  def prox(j = nil)
    raise "Metodo abstracto"
  end
end

class Manual < Estrategia
  def prox(j = nil)
    nil
  end
end

class Uniforme < Estrategia
  def initialize(lista_movimientos)
    super()
    @movimientos = lista_movimientos.map do |sym|
      case sym
      when :Piedra then Piedra.new
      when :Papel then Papel.new
      when :Tijera then Tijera.new
      when :Lagarto then Lagarto.new
      when :Spock then Spock.new
      end
    end.uniq
  end
  
  def prox(j = nil)
    @movimientos.sample(random: @random)
  end
end

class Sesgada < Estrategia
  def initialize(pesos_hash)
    super()
    @pesos = {}
    pesos_hash.each do |jugada_sym, peso|
      jugada = case jugada_sym
               when :Piedra then Piedra.new
               when :Papel then Papel.new
               when :Tijera then Tijera.new
               when :Lagarto then Lagarto.new
               when :Spock then Spock.new
               end
      @pesos[jugada] = peso
    end
    
    total = @pesos.values.sum.to_f
    @prob_acumulada = []
    acumulado = 0.0
    @pesos.each do |jugada, peso|
      acumulado += peso / total
      @prob_acumulada << [acumulado, jugada]
    end
  end
  
  def prox(j = nil)
    r = @random.rand
    @prob_acumulada.find { |prob, jugada| r <= prob }[1]
  end
end

class Copiar < Estrategia
  def initialize
    super()
    @ultima_oponente = nil
    @todas_jugadas = [Piedra.new, Papel.new, Tijera.new, Lagarto.new, Spock.new]
  end
  
  def prox(j = nil)
    jugada = if @ultima_oponente.nil?
      @todas_jugadas.sample(random: @random)
    else
      @ultima_oponente
    end
    @ultima_oponente = j if j
    jugada
  end
end

class Pensar < Estrategia
  def initialize
    super()
    @historial = []
    @todas_jugadas = [Piedra.new, Papel.new, Tijera.new, Lagarto.new, Spock.new]
  end
  
  def prox(j = nil)
    @historial << j if j && j.is_a?(Jugada)
    
    if @historial.empty?
      @todas_jugadas.sample(random: @random)
    else
      frecuencias = Hash.new(0)
      @historial.each { |jugada| frecuencias[jugada.class] += 1 }
      
      jugada_mas_probable_clase = frecuencias.max_by { |_, v| v }[0]
      jugada_mas_probable = jugada_mas_probable_clase.new
      
      jugada_ganadora = @todas_jugadas.find do |jugada|
        jugada.gana_a?(jugada_mas_probable)
      end
      
      jugada_ganadora || @todas_jugadas.sample(random: @random)
    end
  end
end

# Clase partida
class Partida
  attr_reader :jugador1, :jugador2, :puntos1, :puntos2, :ronda_actual, :historial
  
  def initialize(config)
    @jugador1 = {
      nombre: config[:Jugador1][:nombre] || "Jugador 1",
      estrategia: config[:Jugador1][:estrategia]
    }
    @jugador2 = {
      nombre: config[:Jugador2][:nombre] || "Jugador 2",
      estrategia: config[:Jugador2][:estrategia]
    }
    @puntos1 = 0
    @puntos2 = 0
    @ronda_actual = 0
    @historial = []
  end
  
  def rondas(n)
    jugar_hasta { @ronda_actual >= n }
  end
  
  def alcanzar(n)
    jugar_hasta { @puntos1 >= n || @puntos2 >= n }
  end
  
  def jugar_ronda(jugada1_manual = nil, jugada2_manual = nil)
    @ronda_actual += 1
    
    jugada1 = jugada1_manual || @jugador1[:estrategia].prox(@historial.last&.[](:jugada2))
    jugada2 = jugada2_manual || @jugador2[:estrategia].prox(@historial.last&.[](:jugada1))
    
    puntos_ronda = jugada1.puntos(jugada2)
    @puntos1 += puntos_ronda[0]
    @puntos2 += puntos_ronda[1]
    
    @historial << {
      ronda: @ronda_actual,
      jugada1: jugada1,
      jugada2: jugada2,
      puntos1: puntos_ronda[0],
      puntos2: puntos_ronda[1],
      total1: @puntos1,
      total2: @puntos2
    }
    
    if puntos_ronda[0] > puntos_ronda[1]
      @jugador1[:nombre]
    elsif puntos_ronda[1] > puntos_ronda[0]
      @jugador2[:nombre]
    else
      "Empate"
    end
  end
  
  def ganador
    if @puntos1 > @puntos2
      @jugador1[:nombre]
    elsif @puntos2 > @puntos1
      @jugador2[:nombre]
    else
      "Empate"
    end
  end
  
  private
  
  def jugar_hasta(&condicion)
    until condicion.call
      jugar_ronda
    end
    ganador
  end
end

# Detección automática de shoes
def shoes_disponible?
  # Intentar varias formas de detectar shoes
  posibles_rutas = [
    "shoes",                    # En PATH
    "C:\\Program Files\\Shoes\\shoes.exe",
    "C:\\Shoes\\shoes.exe",
    File.expand_path("~/AppData/Local/Shoes/shoes.exe"),
    "C:\\Ruby34-x64\\bin\\shoes.bat"
  ]
  
  # Verificar si alguno existe
  posibles_rutas.each do |ruta|
    if File.exist?(ruta) || system("where #{ruta} >nul 2>&1")
      return true
    end
  end
  
  # Intentar requerir la gema
  begin
    require 'shoes'
    return true
  rescue LoadError
    return false
  end
end

# Interfaz gráfica (shoes) 
def ejecutar_modo_shoes
  begin
    require 'shoes'
    
    Shoes.app(title: "Piedra, Papel, Tijera, Lagarto, Spock", width: 1000, height: 800) do
      background "#F5F5F5"
      
      # Variables de estado
      @partida = nil
      @juego_activo = false
      @modo_juego = :alcanzar
      @puntos_objetivo = 5
      @rondas_objetivo = 10
      
      # Configuración inicial de estrategias
      @estrategias_j1 = [
        {nombre: "Manual", clase: Manual, params: {}},
        {nombre: "Uniforme", clase: Uniforme, params: {lista: [:Piedra, :Papel, :Tijera, :Lagarto, :Spock]}},
        {nombre: "Sesgada", clase: Sesgada, params: {pesos: {Piedra: 2, Papel: 1, Tijera: 1, Lagarto: 1, Spock: 1}}},
        {nombre: "Copiar", clase: Copiar, params: {}},
        {nombre: "Pensar", clase: Pensar, params: {}}
      ]
      
      @estrategias_j2 = [
        {nombre: "Manual", clase: Manual, params: {}},
        {nombre: "Uniforme", clase: Uniforme, params: {lista: [:Piedra, :Papel, :Tijera, :Lagarto, :Spock]}},
        {nombre: "Sesgada", clase: Sesgada, params: {pesos: {Piedra: 2, Papel: 1, Tijera: 1, Lagarto: 1, Spock: 1}}},
        {nombre: "Copiar", clase: Copiar, params: {}},
        {nombre: "Pensar", clase: Pensar, params: {}}
      ]
      
      @estrategia_sel_j1 = @estrategias_j1[1]  # Uniforme por defecto
      @estrategia_sel_j2 = @estrategias_j2[4]  # Pensar por defecto
      
      @nombre_j1 = "Jugador 1"
      @nombre_j2 = "Jugador 2"
      
      # Cargar imágenes (si existen)
      @imagenes = {}
      begin
        @imagenes[:Piedra] = image("Piedra.png", width: 80, height: 80) rescue nil
        @imagenes[:Papel] = image("Papel.png", width: 80, height: 80) rescue nil
        @imagenes[:Tijera] = image("Tijera.png", width: 80, height: 80) rescue nil
        @imagenes[:Lagarto] = image("Lagarto.png", width: 80, height: 80) rescue nil
        @imagenes[:Spock] = image("Spock.png", width: 80, height: 80) rescue nil
      rescue => e
        puts "Error cargando imágenes: #{e.message}"
      end
      
      # Interfaz principal
      stack(margin: 20) do
        # Título
        flow do
          banner "RPTLS - Piedra, Papel, Tijera, Lagarto, Spock", align: "center", margin_bottom: 20
        end
        
        # Panel de configuración
        flow(margin_bottom: 20) do
          stack(width: 0.3, margin_right: 10) do
            background "#E8F4F8", curve: 5
            border "#3498DB", strokewidth: 2
            para "Jugador 1", align: "center", weight: "bold", margin: 5
            
            flow(margin: 5) do
              para "Nombre:", width: 80
              @edit_nombre_j1 = edit_line @nombre_j1, width: 150
            end
            
            flow(margin: 5) do
              para "Estrategia:", width: 80
              @list_estrategia_j1 = list_box items: @estrategias_j1.map { |e| e[:nombre] }, 
                                            choose: @estrategia_sel_j1[:nombre],
                                            width: 150 do |list|
                @estrategia_sel_j1 = @estrategias_j1[list.text]
                actualizar_parametros_ui()
              end
            end
            
            @params_j1 = stack(margin: 5) {}
          end
          
          stack(width: 0.3, margin_right: 10) do
            background "#F8E8F4", curve: 5
            border "#9B59B6", strokewidth: 2
            para "Jugador 2", align: "center", weight: "bold", margin: 5
            
            flow(margin: 5) do
              para "Nombre:", width: 80
              @edit_nombre_j2 = edit_line @nombre_j2, width: 150
            end
            
            flow(margin: 5) do
              para "Estrategia:", width: 80
              @list_estrategia_j2 = list_box items: @estrategias_j2.map { |e| e[:nombre] }, 
                                            choose: @estrategia_sel_j2[:nombre],
                                            width: 150 do |list|
                @estrategia_sel_j2 = @estrategias_j2[list.text]
                actualizar_parametros_ui()
              end
            end
            
            @params_j2 = stack(margin: 5) {}
          end
          
          stack(width: 0.3) do
            background "#F0F8E8", curve: 5
            border "#27AE60", strokewidth: 2
            para "Configuración", align: "center", weight: "bold", margin: 5
            
            flow(margin: 5) do
              para "Modo:", width: 80
              @list_modo = list_box items: ["Alcanzar puntos", "Rondas fijas"], 
                                   width: 150 do |list|
                @modo_juego = list.text == "Alcanzar puntos" ? :alcanzar : :rondas
                actualizar_parametros_ui()
              end
            end
            
            flow(margin: 5) do
              para "Objetivo:", width: 80
              @edit_objetivo = edit_line @puntos_objetivo.to_s, width: 50
            end
            
            button "Iniciar Partida", width: 150, margin_top: 10 do
              iniciar_partida()
            end
            
            button "Ejemplo del Enunciado", width: 150, margin_top: 5 do
              cargar_ejemplo_enunciado()
            end
          end
        end
        
        # Panel del juego
        @panel_juego = stack(margin_top: 20) do
          background "#FFFFFF", curve: 5
          border "#7F8C8D", strokewidth: 2
          
          # Encabezado del juego
          flow(margin: 10) do
            stack(width: 0.3) do
              @label_nombre_j1 = title "Jugador 1", align: "center"
              @label_puntos_j1 = subtitle "0 puntos", align: "center"
            end
            
            stack(width: 0.4) do
              @label_ronda = para "Ronda: 0", align: "center", size: 14
              @label_modo = para "Modo: -", align: "center", size: 12
            end
            
            stack(width: 0.3) do
              @label_nombre_j2 = title "Jugador 2", align: "center"
              @label_puntos_j2 = subtitle "0 puntos", align: "center"
            end
          end
          
          # Jugadas de la ronda
          flow(margin: 10, align: "center") do
            stack(width: 0.4, align: "center") do
              @imagen_j1 = para "Esperando...", align: "center"
              @texto_j1 = para "-", align: "center", size: 12
            end
            
            stack(width: 0.2, align: "center") do
              @label_vs = banner "VS", align: "center"
            end
            
            stack(width: 0.4, align: "center") do
              @imagen_j2 = para "Esperando...", align: "center"
              @texto_j2 = para "-", align: "center", size: 12
            end
          end
          
          # Resultado de la ronda
          @label_resultado = para "", align: "center", size: 16, margin: 10
          
          # Botones de control
          flow(margin: 10, align: "center") do
            @btn_siguiente = button "Siguiente Ronda", margin: 5 do
              jugar_siguiente_ronda()
            end
            
            @btn_automatico = button "Jugar Automático", margin: 5 do
              jugar_automatico()
            end
            
            @btn_reiniciar = button "Reiniciar", margin: 5 do
              iniciar_partida()
            end
          end
          
          # Historial
          @historial_text = stack(height: 100, scroll: true, margin: 10) do
            background "#F9F9F9"
            border "#DDD", strokewidth: 1
            @historial_content = para "", size: 10
          end
          
          # Estado inicial: ocultar hasta iniciar partida
          hide()
        end
        
        # Panel de información
        flow(margin_top: 20) do
          stack(width: 0.5, margin_right: 10) do
            background "#FFF8E1", curve: 5
            border "#F39C12", strokewidth: 2
            para "Información del Proyecto", align: "center", weight: "bold", margin: 5
            para "• Integrantes: Alejandra Mármol (2010408) - Rosa Ramírez (2010527)", margin: 5, size: 10
            para "• Semilla fija: @@semillaPadre = 42", margin: 5, size: 10
            para "• 5 estrategias implementadas", margin: 5, size: 10
          end
          
          stack(width: 0.5) do
            background "#E8F6F3", curve: 5
            border "#1ABC9C", strokewidth: 2
            para "Reglas del Juego", align: "center", weight: "bold", margin: 5
            para "Tijera corta Papel\nPapel tapa Piedra\nPiedra aplasta Lagarto\nLagarto envenena Spock\nSpock rompe Tijera\nTijera decapita Lagarto\nLagarto devora Papel\nPapel desautoriza Spock\nSpock vaporiza Piedra\nPiedra aplasta Tijera", 
                 margin: 5, size: 9
          end
        end
        
        # Inicializar UI de parámetros
        actualizar_parametros_ui()
      end
      
      # Métodos auxiliares
      def actualizar_parametros_ui
        # Limpiar paneles de parámetros
        @params_j1.clear
        @params_j2.clear
        
        # Parámetros para J1
        if @estrategia_sel_j1[:nombre] == "Uniforme"
          @params_j1.append do
            para "Movimientos:", size: 10
            @edit_lista_j1 = edit_line @estrategia_sel_j1[:params][:lista].join(", "), width: 140
          end
        elsif @estrategia_sel_j1[:nombre] == "Sesgada"
          @params_j1.append do
            para "Pesos (Piedra:2, Papel:1,...):", size: 10
            pesos_str = @estrategia_sel_j1[:params][:pesos].map { |k,v| "#{k}:#{v}" }.join(", ")
            @edit_pesos_j1 = edit_line pesos_str, width: 140
          end
        end
        
        # Parámetros para J2
        if @estrategia_sel_j2[:nombre] == "Uniforme"
          @params_j2.append do
            para "Movimientos:", size: 10
            @edit_lista_j2 = edit_line @estrategia_sel_j2[:params][:lista].join(", "), width: 140
          end
        elsif @estrategia_sel_j2[:nombre] == "Sesgada"
          @params_j2.append do
            para "Pesos (Piedra:2, Papel:1,...):", size: 10
            pesos_str = @estrategia_sel_j2[:params][:pesos].map { |k,v| "#{k}:#{v}" }.join(", ")
            @edit_pesos_j2 = edit_line pesos_str, width: 140
          end
        end
        
        # Actualizar label de objetivo según modo
        if @modo_juego == :alcanzar
          @edit_objetivo.text = @puntos_objetivo.to_s
        else
          @edit_objetivo.text = @rondas_objetivo.to_s
        end
      end
      
      def cargar_ejemplo_enunciado
        @edit_nombre_j1.text = "CPU Uniforme"
        @edit_nombre_j2.text = "CPU Pensar"
        @list_estrategia_j1.choose("Uniforme")
        @list_estrategia_j2.choose("Pensar")
        @list_modo.choose("Alcanzar puntos")
        @edit_objetivo.text = "5"
        
        alert("Ejemplo del enunciado cargado:\n\n" +
              "Jugador 1: Uniforme.new([:Piedra, :Papel, :Tijera, :Lagarto, :Spock])\n" +
              "Jugador 2: Pensar.new()\n" +
              "Modo: alcanzar(5)")
      end
      
      def iniciar_partida
        begin
          # Obtener nombres
          @nombre_j1 = @edit_nombre_j1.text
          @nombre_j2 = @edit_nombre_j2.text
          
          # Obtener objetivo
          objetivo = @edit_objetivo.text.to_i
          objetivo = 1 if objetivo < 1
          
          # Crear estrategias según selección
          estrategia1 = crear_estrategia(@estrategia_sel_j1, true)
          estrategia2 = crear_estrategia(@estrategia_sel_j2, false)
          
          # Crear configuración de partida
          config = {
            Jugador1: {nombre: @nombre_j1, estrategia: estrategia1},
            Jugador2: {nombre: @nombre_j2, estrategia: estrategia2}
          }
          
          @partida = Partida.new(config)
          @juego_activo = true
          
          # Actualizar UI
          @label_nombre_j1.text = @nombre_j1
          @label_nombre_j2.text = @nombre_j2
          @label_puntos_j1.text = "0 puntos"
          @label_puntos_j2.text = "0 puntos"
          @label_ronda.text = "Ronda: 0"
          
          if @modo_juego == :alcanzar
            @puntos_objetivo = objetivo
            @label_modo.text = "Modo: Alcanzar #{@puntos_objetivo} puntos"
          else
            @rondas_objetivo = objetivo
            @label_modo.text = "Modo: #{@rondas_objetivo} rondas"
          end
          
          @imagen_j1.clear
          @imagen_j2.clear
          @texto_j1.text = "-"
          @texto_j2.text = "-"
          @label_resultado.text = "Partida iniciada. Presiona 'Siguiente Ronda'"
          @historial_content.text = ""
          
          # Mostrar panel de juego
          @panel_juego.show()
          
          alert("¡Partida iniciada!\n#{@nombre_j1} vs #{@nombre_j2}\n#{@label_modo.text}")
          
        rescue => e
          alert("Error al iniciar partida: #{e.message}")
        end
      end
      
      def crear_estrategia(estrategia_sel, es_j1)
        case estrategia_sel[:nombre]
        when "Manual"
          Manual.new
        when "Uniforme"
          if es_j1 && defined?(@edit_lista_j1)
            lista_str = @edit_lista_j1.text
            movimientos = lista_str.split(",").map(&:strip).map(&:to_sym)
            movimientos = [:Piedra, :Papel, :Tijera, :Lagarto, :Spock] if movimientos.empty?
          elsif !es_j1 && defined?(@edit_lista_j2)
            lista_str = @edit_lista_j2.text
            movimientos = lista_str.split(",").map(&:strip).map(&:to_sym)
            movimientos = [:Piedra, :Papel, :Tijera, :Lagarto, :Spock] if movimientos.empty?
          else
            movimientos = estrategia_sel[:params][:lista]
          end
          Uniforme.new(movimientos)
        when "Sesgada"
          if es_j1 && defined?(@edit_pesos_j1)
            pesos_str = @edit_pesos_j1.text
            pesos = parse_pesos(pesos_str)
          elsif !es_j1 && defined?(@edit_pesos_j2)
            pesos_str = @edit_pesos_j2.text
            pesos = parse_pesos(pesos_str)
          else
            pesos = estrategia_sel[:params][:pesos]
          end
          Sesgada.new(pesos)
        when "Copiar"
          Copiar.new
        when "Pensar"
          Pensar.new
        end
      end
      
      def parse_pesos(pesos_str)
        pesos = {}
        pesos_str.split(",").each do |item|
          if item.include?(":")
            k, v = item.split(":").map(&:strip)
            pesos[k.to_sym] = v.to_i
          end
        end
        pesos = {Piedra: 2, Papel: 1, Tijera: 1, Lagarto: 1, Spock: 1} if pesos.empty?
        pesos
      end
      
      def jugar_siguiente_ronda
        return unless @juego_activo && @partida
        
        # Verificar si el juego ya terminó
        if (@modo_juego == :alcanzar && (@partida.puntos1 >= @puntos_objetivo || @partida.puntos2 >= @puntos_objetivo)) ||
           (@modo_juego == :rondas && @partida.ronda_actual >= @rondas_objetivo)
          alert("¡La partida ya terminó! Ganador: #{@partida.ganador}")
          @btn_siguiente.hide()
          return
        end
        
        # Jugar una ronda
        ganador_ronda = @partida.jugar_ronda
        
        # Actualizar UI
        ultima_ronda = @partida.historial.last
        jugada1 = ultima_ronda[:jugada1]
        jugada2 = ultima_ronda[:jugada2]
        
        @label_ronda.text = "Ronda: #{@partida.ronda_actual}"
        @label_puntos_j1.text = "#{@partida.puntos1} puntos"
        @label_puntos_j2.text = "#{@partida.puntos2} puntos"
        
        # Mostrar imágenes o texto
        @imagen_j1.clear
        @imagen_j2.clear
        
        # Intentar mostrar imágenes, si no hay, mostrar texto
        if @imagenes[jugada1.nombre]
          @imagen_j1.append { image(@imagenes[jugada1.nombre].path, width: 80, height: 80) }
        else
          @imagen_j1.append { para jugada1.nombre.to_s, size: 16, align: "center" }
        end
        
        if @imagenes[jugada2.nombre]
          @imagen_j2.append { image(@imagenes[jugada2.nombre].path, width: 80, height: 80) }
        else
          @imagen_j2.append { para jugada2.nombre.to_s, size: 16, align: "center" }
        end
        
        @texto_j1.text = jugada1.class.to_s
        @texto_j2.text = jugada2.class.to_s
        
        # Mostrar resultado
        if ganador_ronda == "Empate"
          @label_resultado.text = "¡Empate!"
          @label_resultado.style(stroke: "#7F8C8D")
        elsif ganador_ronda == @nombre_j1
          @label_resultado.text = "¡#{@nombre_j1} gana la ronda!"
          @label_resultado.style(stroke: "#3498DB")
        else
          @label_resultado.text = "¡#{@nombre_j2} gana la ronda!"
          @label_resultado.style(stroke: "#9B59B6")
        end
        
        # Actualizar historial
        actualizar_historial()
        
        # Verificar si terminó el juego
        if (@modo_juego == :alcanzar && (@partida.puntos1 >= @puntos_objetivo || @partida.puntos2 >= @puntos_objetivo)) ||
           (@modo_juego == :rondas && @partida.ronda_actual >= @rondas_objetivo)
          
          mensaje_final = "¡Partida terminada!\n"
          mensaje_final += "Rondas jugadas: #{@partida.ronda_actual}\n"
          mensaje_final += "#{@nombre_j1}: #{@partida.puntos1} puntos\n"
          mensaje_final += "#{@nombre_j2}: #{@partida.puntos2} puntos\n"
          mensaje_final += "Ganador: #{@partida.ganador}"
          
          alert(mensaje_final)
          @btn_siguiente.hide()
        end
      end
      
      def jugar_automatico
        return unless @juego_activo && @partida
        
        # Jugar hasta terminar
        if @modo_juego == :alcanzar
          @partida.alcanzar(@puntos_objetivo)
        else
          @partida.rondas(@rondas_objetivo)
        end
        
        # Actualizar UI con última ronda
        if @partida.historial.any?
          ultima_ronda = @partida.historial.last
          jugada1 = ultima_ronda[:jugada1]
          jugada2 = ultima_ronda[:jugada2]
          
          @label_ronda.text = "Ronda: #{@partida.ronda_actual}"
          @label_puntos_j1.text = "#{@partida.puntos1} puntos"
          @label_puntos_j2.text = "#{@partida.puntos2} puntos"
          
          # Mostrar últimas jugadas
          @imagen_j1.clear
          @imagen_j2.clear
          
          if @imagenes[jugada1.nombre]
            @imagen_j1.append { image(@imagenes[jugada1.nombre].path, width: 80, height: 80) }
          else
            @imagen_j1.append { para jugada1.nombre.to_s, size: 16, align: "center" }
          end
          
          if @imagenes[jugada2.nombre]
            @imagen_j2.append { image(@imagenes[jugada2.nombre].path, width: 80, height: 80) }
          else
            @imagen_j2.append { para jugada2.nombre.to_s, size: 16, align: "center" }
          end
          
          @texto_j1.text = jugada1.class.to_s
          @texto_j2.text = jugada2.class.to_s
          
          @label_resultado.text = "¡Partida completada! Ganador: #{@partida.ganador}"
          @label_resultado.style(stroke: "#E74C3C")
          
          actualizar_historial()
          @btn_siguiente.hide()
          
          alert("¡Partida completada en modo automático!\nGanador: #{@partida.ganador}")
        end
      end
      
      def actualizar_historial
        @historial_content.text = ""
        @partida.historial.last(10).reverse.each do |ronda|
          texto = "Ronda #{ronda[:ronda]}: #{ronda[:jugada1].nombre} vs #{ronda[:jugada2].nombre} "
          texto += "(#{ronda[:puntos1]}-#{ronda[:puntos2]}) "
          texto += "Total: #{ronda[:total1]}-#{ronda[:total2]}"
          @historial_content.append { para texto, size: 9 }
        end
      end
    end
    
  rescue LoadError => e
    puts "Error: No se pudo cargar Shoes"
    puts "Mensaje: #{e.message}"
    ejecutar_modo_consola
  end
end

# Interfaz consola
def ejecutar_modo_consola
  puts "=" * 70
  puts "MODO CONSOLA - PROYECTO RPTLS"
  puts "=" * 70
  
  puts "\nEJEMPLO EXACTO DEL ENUNCIADO:"
  puts "-" * 40
  
  # Configuracion de estrategias 
  jug1 = Uniforme.new([:Piedra, :Papel, :Tijera, :Lagarto, :Spock])
  jug2 = Pensar.new()
  
  puts "jug1 = Uniforme.new([:Piedra, :Papel, :Tijera, :Lagarto, :Spock])"
  puts "jug2 = Pensar.new()"
  
  # Inicializacion de partida 
  partida = Partida.new({
    :Jugador1 => {nombre: "CPU Uniforme", estrategia: jug1},
    :Jugador2 => {nombre: "CPU Pensar", estrategia: jug2}
  })
  
  puts "partida = Partida.new({:Jugador1 => jug1, :Jugador2 => jug2})"
  
  # Ejecutar modo 'Alcanzar' 5 puntos 
  puts "\npartida.alcanzar(5)"
  puts "-" * 40
  
  ganador = partida.alcanzar(5)
  
  puts "\n" + "=" * 70
  puts "RESULTADO FINAL"
  puts "=" * 70
  puts "Rondas jugadas: #{partida.ronda_actual}"
  puts "#{partida.jugador1[:nombre]}: #{partida.puntos1} puntos"
  puts "#{partida.jugador2[:nombre]}: #{partida.puntos2} puntos"
  puts "Ganador: #{ganador}"
  puts "=" * 70
  
end

# Programa inicial
if __FILE__ == $0
  puts "=" * 70
  puts "PROYECTO 3: PIEDRA, PAPEL, TIJERA, LAGARTO, SPOCK"
  puts "Archivo: RPTLS.rb"
  puts "=" * 70
  
  # Detectar si Shoes esta disponible
  shoes_available = shoes_disponible?
  
  if shoes_available && ARGV.empty?
    puts "\nShoes detectado. ¿Cómo quiere ejecutar?"
    puts "1. Interfaz grafica (Shoes)"
    puts "2. Modo consola"
    print "Seleccione (1-2): "
    
    opcion = gets.chomp
    
    if opcion == "1"
      ejecutar_modo_shoes
    else
      ejecutar_modo_consola
    end
    
  elsif ARGV.include?("--shoes") || ARGV.include?("-s")
    # Forzar modo Shoes
    ejecutar_modo_shoes
    
  elsif ARGV.include?("--console") || ARGV.include?("-c")
    # Forzar modo consola
    ejecutar_modo_consola
    
  else
    # Por defecto, modo consola
    ejecutar_modo_consola
  end
end